# FAQ

**Q:** What credentials are required?  
**A:** Only Zoom email and password.

**Q:** Can I see tickets for multiple agents?  
**A:** No, only tickets accessible to the logged-in agent are displayed.

**Q:** Can I create tickets for missed calls?  
**A:** Yes, you can create a new ticket from the widget for any call.

**Q:** Do I need API keys?  
**A:** No, Zoom email & password are sufficient.
